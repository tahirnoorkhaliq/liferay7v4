package com.tahir.dataimport.application;

import com.liferay.headless.batch.engine.client.resource.v1_0.ImportTaskResource;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.Set;
import java.util.stream.Collectors;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Application;

import org.osgi.service.component.annotations.Component;
import org.osgi.service.jaxrs.whiteboard.JaxrsWhiteboardConstants;

/**
 * @author Tahir
 */
@Component(
	property = {
		JaxrsWhiteboardConstants.JAX_RS_APPLICATION_BASE + "=/greetings",
		JaxrsWhiteboardConstants.JAX_RS_NAME + "=Greetings.Rest"
	},
	service = Application.class
)
public class UserDataImportApplication extends Application {

	public Set<Object> getSingletons() {
		return Collections.<Object>singleton(this);
	}

	@GET
	@Produces("text/plain")
	public String working() {
		return "It works!";
	}

	@GET
	@Path("/morning")
	@Produces("text/plain")
	public String hello() {
		
		InputStream is = UserDataImportApplication.class.getClassLoader().getResourceAsStream("userloadtest.json");
		String jsonString = printInputStream(is);
		ImportTaskResource.Builder builder = ImportTaskResource.builder();
		ImportTaskResource importTaskResource = builder.authentication("test@liferay.com", "test").build();
		System.out.println("=============================");
		System.out.println(jsonString.length());
		try {
			Thread.sleep(3000);
			System.out.println(importTaskResource.postImportTask(
					  String.valueOf("com.liferay.headless.admin.user.dto.v1_0.UserAccount"), null,
					  null, null, null, null, null, jsonString));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Good morning!";
	}

	@GET
	@Path("/morning/{name}")
	@Produces("text/plain")
	public String morning(
		@PathParam("name") String name,
		@QueryParam("drink") String drink) {

		String greeting = "Good Morning " + name;

		if (drink != null) {
			greeting += ". Would you like some " + drink + "?";
		}

		return greeting;
	}

	private static String printInputStream(InputStream is) {

		try {
			String text = new BufferedReader(

					new InputStreamReader(is, StandardCharsets.UTF_8)).lines().collect(Collectors.joining("\n"));
			System.out.println(text.length());
			return text;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;

	}

}